package tarea6.reproductor.activities;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;

import android.content.Context;
import android.content.Intent;
import android.media.AudioManager;
import android.media.MediaPlayer;
import android.os.Bundle;
import android.view.MotionEvent;
import android.widget.Button;
import android.widget.MediaController;
import android.widget.SeekBar;

import java.io.IOException;
import java.util.List;

import tarea6.reproductor.databinding.ActivityStreamingBinding;
import tarea6.reproductor.resources.MediaAdapter;
import tarea6.reproductor.resources.MediaContentLoader;
import tarea6.reproductor.resources.MediaItem;

/**
 * Una actividad que muestra una lista de elementos multimedia para reproducción en streaming.
 * Esta actividad utiliza un RecyclerView para mostrar los elementos multimedia disponibles para reproducción.
 * Permite la reproducción de audio y video en la misma actividad.
 * Implementa la interfaz MediaAdapter.OnMediaClickListener para manejar los clics en los elementos multimedia.
 * Implementa MediaPlayer.OnPreparedListener y MediaController.MediaPlayerControl para controlar la reproducción de los medios.
 */
public class StreamingActivity extends AppCompatActivity implements MediaAdapter.OnMediaClickListener, MediaPlayer.OnPreparedListener, MediaController.MediaPlayerControl {

    // Declaración de variables
    private ActivityStreamingBinding binding; // Binding para acceder a los elementos de la interfaz
    private MediaPlayer mediaPlayer; // MediaPlayer para reproducir audio
    private MediaController mediaController; // MediaController para controlar la reproducción
    private AudioManager audioManager; // AudioManager para controlar el volumen

    /**
     * Método que se ejecuta al crear la actividad.
     * @param savedInstanceState Instancia guardada de la actividad.
     */
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        binding = ActivityStreamingBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());

        // Configurar el RecyclerView
        setupRecyclerView();

        // Configurar el botón de regreso
        setupBackButton();

        // Inicializa el MediaPlayer
        setupMediaPlayer();

        // Configuro la seekBar
        setupVolumeControl();
    }

    /**
     * Configura el RecyclerView para mostrar los elementos multimedia disponibles para reproducción.
     * Carga los datos desde un archivo JSON y utiliza un adaptador personalizado (MediaAdapter).
     */
    private void setupRecyclerView() {
        // Cargar los datos desde el archivo JSON
        List<MediaItem> mediaList = MediaContentLoader.loadMediaFromJSON(this, "2");
        MediaAdapter adapter = new MediaAdapter(this, mediaList, this);

        // Configuro el recyclerView
        binding.recyclerViewStreaming.setHasFixedSize(true);
        binding.recyclerViewStreaming.setAdapter(adapter);
        binding.recyclerViewStreaming.setLayoutManager(new LinearLayoutManager(this));
    }

    /**
     * Inicializa el MediaPlayer y configura el Listener para la preparación del MediaPlayer.
     */
    private void setupMediaPlayer(){
        mediaPlayer = new MediaPlayer();
        mediaPlayer.setOnPreparedListener(this);
    }

    /**
     * Configura la SeekBar para controlar el volumen del sistema
     * utilizando el AudioManager.
     */
    private void setupVolumeControl() {
        // Inicializa el AudioManager
        audioManager = (AudioManager) getSystemService(Context.AUDIO_SERVICE);

        // Configura la SeekBar para controlar el volumen
        binding.seekBarVolume.setMax(audioManager.getStreamMaxVolume(AudioManager.STREAM_MUSIC));
        binding.seekBarVolume.setProgress(audioManager.getStreamVolume(AudioManager.STREAM_MUSIC));

        binding.seekBarVolume.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            @Override
            public void onProgressChanged(SeekBar seekBar, int progress, boolean fromUser) {
                // Cambiar el volumen del sistema al progreso del SeekBar
                audioManager.setStreamVolume(AudioManager.STREAM_MUSIC, progress, 0);
            }

            @Override
            public void onStartTrackingTouch(SeekBar seekBar) {

            }

            @Override
            public void onStopTrackingTouch(SeekBar seekBar) {

            }
        });
    }

    /**
     * Configura el botón de regreso para finalizar la actividad actual.
     */
    private void setupBackButton() {
        // Encuentra el botón por su ID y configura el evento de clic
        Button buttonBack = binding.buttonBack;
        buttonBack.setOnClickListener(v -> {
            // Finaliza la actividad actual
            finish();
        });
    }

    /**
     * Método llamado cuando se hace clic en un elemento multimedia en la lista.
     * Reproduce el audio o video según el tipo de medio seleccionado.
     *
     * @param item El elemento multimedia seleccionado.
     */
    @Override
    public void onPlayClicked(MediaItem item) {
        if ("2".equals(item.getTipo())) {
            boolean esVideo = item.getUri().endsWith(".mp4");

            if (esVideo) {
                // Pausa el audio si está reproduciéndose
                if (mediaPlayer != null && mediaPlayer.isPlaying()) {
                    mediaPlayer.pause();
                }
                // Lanzar actividad de vídeo
                Intent intent = new Intent(StreamingActivity.this, VideoPlayerActivity.class);
                intent.putExtra("video_uri", item.getUri());
                startActivity(intent);
            } else {
                // Reproducir audio en la misma actividad
                if (mediaPlayer == null) {
                    mediaPlayer = new MediaPlayer();
                    mediaPlayer.setOnPreparedListener(this);
                } else {
                    mediaPlayer.reset(); // Restablecer el MediaPlayer para estar seguro de que está limpio para un nuevo uso
                }
                try {
                    mediaPlayer.setDataSource(item.getUri());
                    mediaPlayer.setAudioStreamType(AudioManager.STREAM_MUSIC);
                    mediaPlayer.prepareAsync(); // Preparar el MediaPlayer de manera asíncrona
                } catch (IOException e) {
                    e.printStackTrace(); // Es importante manejar excepciones aquí para evitar que tu app se crashee por un error de I/O
                }
            }
        }
    }

    // Implementación de MediaPlayerControl
    /**
     * Método llamado cuando se presiona el botón de reproducción.
     * Inicia la reproducción del medio actual utilizando el reproductor multimedia.
     */
    @Override
    public void start() {
        mediaPlayer.start();
    }

    /**
     * Método llamado cuando se presiona el botón de pausa o cuando la actividad está pausada.
     * Pausa la reproducción del medio actual si el reproductor multimedia está reproduciendo.
     */
    @Override
    public void pause() {
        // Pausar la reproducción solo si el reproductor multimedia está reproduciendo
        if (mediaPlayer != null && mediaPlayer.isPlaying()) {
            mediaPlayer.pause();
            mediaController.show(0); // Muestra el botón de play cuando la reproducción se pausa
        }
    }

    /**
     * Método llamado cuando la actividad está a punto de detenerse.
     * Detiene y libera los recursos utilizados por el reproductor multimedia.
     */
    @Override
    protected void onStop() {
        super.onStop();
        if (mediaPlayer != null) {
            if (mediaPlayer.isPlaying()) {
                mediaPlayer.stop();
            }
            mediaPlayer.release();
            mediaPlayer = null;
        }
    }

    /**
     * Obtiene la duración del medio actual en reproducción.
     * @return La duración del medio en milisegundos, o 0 si el reproductor multimedia es nulo.
     */
    @Override
    public int getDuration() {
        if (mediaPlayer != null) {
            return mediaPlayer.getDuration();
        }
        return 0;
    }

    /**
     * Obtiene la posición actual de reproducción del medio.
     * @return La posición actual de reproducción en milisegundos, o 0 si el reproductor multimedia es nulo.
     */
    @Override
    public int getCurrentPosition() {
        if (mediaPlayer != null) {
            return mediaPlayer.getCurrentPosition();
        }
        return 0;
    }

    /**
     * Método llamado cuando se presiona el botón de avance rápido.
     * Avanza la reproducción del medio actual por la cantidad especificada.
     * @param pos La cantidad de milisegundos para avanzar la reproducción.
     */
    @Override
    public void seekTo(int pos) {
        mediaPlayer.seekTo(pos);
    }

    /**
     * Indica si el medio está actualmente en reproducción.
     * @return True si el medio está reproduciéndose, false de lo contrario.
     */
    @Override
    public boolean isPlaying() {
        return mediaPlayer != null && mediaPlayer.isPlaying();
    }

    /**
     * Obtiene el porcentaje del búfer actual.
     * @return El porcentaje del búfer actual, siempre devuelve 0 ya que no es necesario para reproducción local.
     */
    @Override
    public int getBufferPercentage() {
        return 0; // No es necesario para reproducción local
    }

    /**
     * Indica si la reproducción puede ser pausada.
     * @return True si la reproducción puede ser pausada, false de lo contrario.
     */
    @Override
    public boolean canPause() {
        return true;
    }

    /**
     * Indica si la reproducción puede retroceder.
     * @return True si la reproducción puede retroceder, false de lo contrario.
     */
    @Override
    public boolean canSeekBackward() {
        return true;
    }

    /**
     * Indica si la reproducción puede avanzar.
     * @return True si la reproducción puede avanzar, false de lo contrario.
     */
    @Override
    public boolean canSeekForward() {
        return true;
    }

    /**
     * Obtiene el ID de sesión de audio asociado con el reproductor multimedia.
     * @return El ID de sesión de audio del reproductor multimedia.
     */
    @Override
    public int getAudioSessionId() {
        return mediaPlayer.getAudioSessionId();
    }

    /**
     * Maneja los eventos de toque en la pantalla.
     * Muestra el MediaController si está disponible.
     * @param event El evento de toque.
     * @return True si el evento ha sido manejado, false de lo contrario.
     */
    @Override
    public boolean onTouchEvent(MotionEvent event) {
        if (mediaController != null) {
            mediaController.show();
        }
        // Devuelve true para indicar que el evento ha sido manejado
        return false;
    }

    /**
     * Método llamado cuando el MediaPlayer está preparado para la reproducción.
     * Crea y muestra el MediaController, y comienza la reproducción del medio.
     * @param mp El reproductor multimedia que está preparado.
     */
    @Override
    public void onPrepared(MediaPlayer mp) {
        mediaController = new MediaController(StreamingActivity.this);
        mediaController.setMediaPlayer(this);
        mediaController.setAnchorView(binding.recyclerViewStreaming);

        mediaController.setEnabled(true);
        mediaController.show(0);

        // Iniciar reproducción
        mediaPlayer.start();
    }

    /**
     * Método llamado cuando la actividad está a punto de ser destruida.
     * Limpia los recursos utilizados por el reproductor multimedia y el controlador de medios.
     */
    @Override
    protected void onDestroy() {
        super.onDestroy();

        // Ocultar el MediaController para prevenir WindowLeaks
        if (mediaController != null) {
            mediaController.removeAllViews();
            mediaController = null; // opcional, depende si quieres reusar MediaController
        }

        // Detener y liberar el MediaPlayer
        if (mediaPlayer != null) {
            if (mediaPlayer.isPlaying()) {
                mediaPlayer.stop();
            }
            mediaPlayer.release();
            mediaPlayer = null;
        }
    }
}