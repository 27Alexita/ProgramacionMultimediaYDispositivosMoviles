package tarea6.reproductor.resources;

import android.content.Context;
import android.content.Intent;
import android.os.Build;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import java.util.List;

import tarea6.reproductor.R;
import tarea6.reproductor.activities.VideoPlayerActivity;

/**
 * Este adaptador se utiliza para mostrar elementos multimedia en un RecyclerView.
 */
public class MediaAdapter extends RecyclerView.Adapter<MediaAdapter.ViewHolder> {

    // Declaración de variables
    private Context context; // Contexto de la aplicación
    private List<MediaItem> mediaList; // Lista de elementos multimedia
    private OnMediaClickListener onMediaClickListener; // Listener para el clic en el botón de reproducción

    /**
     * Interfaz para manejar los eventos de clic en los elementos multimedia.
     */
    public interface OnMediaClickListener {
        void onPlayClicked(MediaItem item);
    }

    /**
     * Constructor del adaptador.
     *
     * @param context              Contexto de la aplicación.
     * @param mediaList            Lista de elementos multimedia.
     * @param onMediaClickListener Listener para manejar los eventos de clic en los elementos multimedia.
     */
    public MediaAdapter(Context context, List<MediaItem> mediaList, OnMediaClickListener onMediaClickListener) {
        this.context = context;
        this.mediaList = mediaList;
        this.onMediaClickListener = onMediaClickListener;
    }

    /**
     * Método para crear un ViewHolder.
     *
     * @param parent   Grupo de vistas padre.
     * @param viewType Tipo de vista.
     * @return ViewHolder creado.
     */
    @NonNull
    @Override
    public MediaAdapter.ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(context).inflate(R.layout.media_item, parent, false);
        return new ViewHolder(view);
    }

    /**
     * Método para enlazar un ViewHolder con los datos de un elemento multimedia.
     *
     * @param holder   ViewHolder a enlazar.
     * @param position Posición del elemento multimedia en la lista.
     */
    @Override
    public void onBindViewHolder(@NonNull MediaAdapter.ViewHolder holder, int position) {
        MediaItem item = mediaList.get(position);
        holder.textViewNombre.setText(item.getNombre());
        holder.textViewDescripcion.setText(item.getDescripcion());

        // Elimina la extensión del archivo de imagen y convierte el nombre a minúsculas para el ID del recurso
        String imageName = item.getImagen().substring(0, item.getImagen().lastIndexOf('.')).toLowerCase();
        int imageResId = context.getResources().getIdentifier(imageName, "drawable", context.getPackageName());
        holder.imageViewPrincipal.setImageResource(imageResId);

        // Configura las demás imágenes
        holder.imageViewTipoArchivo.setImageResource(item.getTipoImagenDrawable());
        holder.imageViewPlay.setImageResource(item.getPlayButtonDrawable());

        // Configura el fondo de la imagen de reproducción
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
            holder.imageViewPlay.setBackgroundResource(R.drawable.item_ripple);
        } else {
            //holder.imageViewPlay.setBackgroundResource(R.drawable.item_selector);
        }

        // Configurar el listener para reproducir el archivo
        holder.imageViewPlay.setOnClickListener(v -> {
            if(onMediaClickListener != null){
                if (item.getTipo().equals("1")) { // Si es un video
                    Intent videoIntent = new Intent(context, VideoPlayerActivity.class);
                    videoIntent.putExtra("video_uri", item.getUri());
                    context.startActivity(videoIntent);
                } else {
                    onMediaClickListener.onPlayClicked(item);
                }
            }
        });
    }

    /**
     * Método para obtener la cantidad de elementos multimedia en la lista.
     *
     * @return Cantidad de elementos multimedia.
     */
    @Override
    public int getItemCount() {
        return mediaList.size();
    }

    /**
     * Clase ViewHolder que contiene las vistas de un elemento de la lista.
     */
    public class ViewHolder extends RecyclerView.ViewHolder {

        // Declaración de variables
        private TextView textViewNombre, textViewDescripcion; // Vistas de texto
        private ImageView imageViewPrincipal, imageViewPlay, imageViewTipoArchivo; // Vistas de imagen

        /**
         * Constructor de la clase ViewHolder.
         *
         * @param itemView Vista del elemento de la lista.
         */
        public ViewHolder(@NonNull View itemView) {
            super(itemView);
            textViewNombre = itemView.findViewById(R.id.textViewNombre);
            textViewDescripcion = itemView.findViewById(R.id.textViewDescripcion);
            imageViewPrincipal = itemView.findViewById(R.id.imageViewPrincipal);
            imageViewPlay = itemView.findViewById(R.id.imageViewPlay);
            imageViewTipoArchivo = itemView.findViewById(R.id.imageViewTipoArchivo);
        }
    }
}
