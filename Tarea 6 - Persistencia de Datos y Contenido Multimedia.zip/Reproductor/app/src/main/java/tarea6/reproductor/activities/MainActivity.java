package tarea6.reproductor.activities;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;

import tarea6.reproductor.databinding.ActivityMainBinding;

/**
 * Esta actividad representa la pantalla principal de la aplicación.
 * Permite al usuario acceder a las actividades de reproducción de audio, video y streaming.
 */
public class MainActivity extends AppCompatActivity {

    // Declaración de variables
    private ActivityMainBinding binding; // Binding para acceder a los elementos de la interfaz

    /**
     * Método que se ejecuta al crear la actividad.
     * @param savedInstanceState Instancia guardada de la actividad.
     */
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        // Inicialización del binding
        binding = ActivityMainBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());

        // Configuración de los botones
        setupButtons();
    }

    /**
     * Método para configurar los botones de la interfaz.
     * Configura los clics de los botones para abrir las actividades correspondientes.
     */
    private void setupButtons() {
        // Botón para abrir la actividad de audio
        binding.imageButtonAudio.setOnClickListener(v -> openAudioActivity());

        // Botón para abrir la actividad de video
        binding.imageButtonVideo.setOnClickListener(v -> openVideoActivity());

        // Botón para abrir la actividad de streaming
        binding.imageButtonStreaming.setOnClickListener(v -> openStreamingActivity());
    }

    /**
     * Método para abrir la actividad de reproducción de audio.
     */
    private void openAudioActivity() {
        Intent audioIntent = new Intent(this, AudioActivity.class);
        startActivity(audioIntent);
    }

    /**
     * Método para abrir la actividad de reproducción de video.
     */
    private void openVideoActivity() {
        Intent videoIntent = new Intent(this, VideoActivity.class);
        startActivity(videoIntent);
    }

    /**
     * Método para abrir la actividad de reproducción de streaming.
     */
    private void openStreamingActivity() {
        Intent streamingIntent = new Intent(this, StreamingActivity.class);
        startActivity(streamingIntent);
    }
}