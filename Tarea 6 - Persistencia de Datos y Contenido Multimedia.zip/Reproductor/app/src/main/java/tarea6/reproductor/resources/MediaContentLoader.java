package tarea6.reproductor.resources;

import android.content.Context;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.IOException;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.List;

import tarea6.reproductor.R;

/**
 * Esta clase proporciona métodos estáticos para cargar elementos multimedia desde un archivo JSON.
 */
public class MediaContentLoader {

    /**
     * Carga los elementos multimedia de un archivo JSON según el tipo especificado.
     *
     * @param context   Contexto de la aplicación.
     * @param mediaType Tipo de medios a cargar: "0" para audio, "1" para video, "2" para streaming.
     * @return Una lista de objetos MediaItem cargados desde el archivo JSON.
     */
    public static List<MediaItem> loadMediaFromJSON(Context context, String mediaType) {
        List<MediaItem> mediaList = new ArrayList<>();
        try {
            // Abre el archivo JSON desde la carpeta raw
            InputStream is = context.getResources().openRawResource(R.raw.medialist);
            int size = is.available();
            byte[] buffer = new byte[size];
            is.read(buffer);
            is.close();
            String json = new String(buffer, "UTF-8");

            JSONObject jsonObject = new JSONObject(json);
            JSONArray jsonArray = jsonObject.getJSONArray("recursos_list");

            // Itera sobre los elementos del JSON para cargar los medios
            for (int i = 0; i < jsonArray.length(); i++) {
                JSONObject jsonMedia = jsonArray.getJSONObject(i);
                String tipo = jsonMedia.getString("tipo");

                // Solo añade el elemento a la lista si su tipo coincide con el parámetro 'mediaType'
                if (tipo.equals(mediaType)) {
                    String nombre = jsonMedia.getString("nombre");
                    String descripcion = jsonMedia.getString("descripcion");
                    String uri = jsonMedia.getString("URI");
                    String imagen = jsonMedia.getString("imagen");
                    mediaList.add(new MediaItem(nombre, descripcion, tipo, uri, imagen));
                }
            }
        } catch (IOException | JSONException e) {
            e.printStackTrace();
        }
        return mediaList;
    }
}
