package tarea6.reproductor.activities;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;

import android.content.Context;
import android.content.res.AssetFileDescriptor;
import android.media.AudioManager;
import android.media.MediaPlayer;
import android.os.Bundle;
import android.view.MotionEvent;
import android.view.View;
import android.widget.Button;
import android.widget.MediaController;
import android.widget.MediaController.MediaPlayerControl;
import android.widget.SeekBar;

import java.util.List;

import tarea6.reproductor.databinding.ActivityAudioBinding;
import tarea6.reproductor.resources.MediaAdapter;
import tarea6.reproductor.resources.MediaContentLoader;
import tarea6.reproductor.resources.MediaItem;

/**
 * Esta actividad permite reproducir archivos de audio y controlar el volumen mediante una SeekBar.
 */
public class AudioActivity extends AppCompatActivity implements MediaAdapter.OnMediaClickListener, MediaPlayerControl {

    // Declaración de variables
    private ActivityAudioBinding binding; // Binding para acceder a los elementos de la interfaz
    private MediaPlayer mediaPlayer; // Reproductor de audio
    private MediaController mediaController; // Controlador de medios
    private AudioManager audioManager; // Administrador de audio

    /**
     * Método que se ejecuta al crear la actividad.
     * @param savedInstanceState Instancia guardada de la actividad.
     */
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        // Inicializo el binding
        binding = ActivityAudioBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());

        // Configuro el recyclerView
        setupRecyclerView();

        // Inicializo el reproductor
        setupMediaPlayer();

        // Configuro la seekBar
        setupVolumeControl();

        // Configurar el botón de regreso
        setupBackButton();
    }

    /**
     * Configura el RecyclerView para mostrar los elementos multimedia disponibles para reproducción.
     * Carga los datos desde un archivo JSON y utiliza un adaptador personalizado (MediaAdapter).
     */
    private void setupRecyclerView() {
        // Cargar los datos desde el archivo JSON
        List<MediaItem> mediaList = MediaContentLoader.loadMediaFromJSON(this, "0");
        MediaAdapter adapter = new MediaAdapter(this, mediaList, this);

        // Configuro el recyclerView
        binding.recyclerViewAudio.setHasFixedSize(true);
        binding.recyclerViewAudio.setAdapter(adapter);
        binding.recyclerViewAudio.setLayoutManager(new LinearLayoutManager(this));
    }

    /**
     * Método que inicializa el reproductor de audio y el controlador de medios.
     */
    private void setupMediaPlayer() {
        mediaPlayer = new MediaPlayer();
        mediaController = new MediaController(this);
        // Asigna el MediaPlayer al MediaController
        mediaController.setMediaPlayer(this);
        mediaController.setAnchorView(binding.recyclerViewAudio);
        // Permite que los controles de MediaController aparezcan sobre la vista anclada
        mediaController.setEnabled(true);
    }

    /**
     * Método que configura la SeekBar para controlar el volumen del sistema
     * mediante el AudioManager.
     */
    private void setupVolumeControl() {
        // Inicializa el AudioManager
        audioManager = (AudioManager) getSystemService(Context.AUDIO_SERVICE);

        // Configura la SeekBar para controlar el volumen
        binding.seekBarVolume.setMax(audioManager.getStreamMaxVolume(AudioManager.STREAM_MUSIC));
        binding.seekBarVolume.setProgress(audioManager.getStreamVolume(AudioManager.STREAM_MUSIC));

        binding.seekBarVolume.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            @Override
            public void onProgressChanged(SeekBar seekBar, int progress, boolean fromUser) {
                // Cambiar el volumen del sistema al progreso del SeekBar
                audioManager.setStreamVolume(AudioManager.STREAM_MUSIC, progress, 0);
            }

            @Override
            public void onStartTrackingTouch(SeekBar seekBar) {

            }

            @Override
            public void onStopTrackingTouch(SeekBar seekBar) {

            }
        });
    }

    /**
     * Método que configura el botón de regreso para finalizar la actividad.
     */
    private void setupBackButton() {
        // Encuentra el botón por su ID y configura el evento de clic
        Button buttonBack = binding.buttonBack;
        buttonBack.setOnClickListener(v -> {
            // Finaliza la actividad actual
            finish();
        });
    }

    /**
     * Método que se ejecuta al hacer clic en un elemento de la lista de medios.
     * @param item Elemento de la lista de medios.
     */
    @Override
    public void onPlayClicked(MediaItem item) {
        int audioResId = getResources().getIdentifier(item.getUri(), "raw", getPackageName());
        try{
            mediaPlayer.reset();
            AssetFileDescriptor afd = getResources().openRawResourceFd(audioResId);
            if (afd == null) return;
            mediaPlayer.setDataSource(afd.getFileDescriptor(), afd.getStartOffset(), afd.getLength());
            afd.close();
            mediaPlayer.prepare();
            mediaPlayer.start();
            mediaController.show(0);
        } catch (Exception ex){
            ex.printStackTrace();
        }
    }

    // Métodos de la interfaz MediaPlayerControl
    /**
     * Inicia o reanuda la reproducción del archivo de audio.
     */
    @Override
    public void start() {
        mediaPlayer.start();
    }

    /**
     * Pausa la reproducción del archivo de audio.
     * Muestra los controles de reproducción si están disponibles.
     */
    @Override
    public void pause() {
        if (mediaPlayer != null && mediaPlayer.isPlaying()) {
            mediaPlayer.pause();
            mediaController.show(0); // Considera mostrar los controles al pausar
        }
    }

    /**
     * Pausa la reproducción del archivo de audio cuando la actividad está pausada.
     */
    @Override
    protected void onPause() {
        super.onPause();
        pause(); // Pausar la reproducción cuando la actividad esté pausada
    }

    /**
     * Detiene la reproducción del archivo de audio cuando la actividad se detiene.
     * Libera los recursos del reproductor multimedia.
     */
    @Override
    protected void onStop() {
        super.onStop();
        if (mediaPlayer != null) {
            if (mediaPlayer.isPlaying()) {
                mediaPlayer.stop();
            }
            mediaPlayer.release();
            mediaPlayer = null;
        }
    }

    /**
     * Obtiene la duración del archivo de audio actualmente cargado en el reproductor.
     *
     * @return La duración del archivo de audio en milisegundos.
     */
    @Override
    public int getDuration() {
        if (mediaPlayer != null) {
            return mediaPlayer.getDuration();
        }
        return 0;
    }

    /**
     * Obtiene la posición actual de reproducción en el archivo de audio.
     *
     * @return La posición actual de reproducción en milisegundos.
     */
    @Override
    public int getCurrentPosition() {
        if (mediaPlayer != null) {
            return mediaPlayer.getCurrentPosition();
        }
        return 0;
    }

    /**
     * Se mueve a una posición específica en el archivo de audio.
     *
     * @param pos La posición en milisegundos a la que se desea mover.
     */
    @Override
    public void seekTo(int pos) {
        mediaPlayer.seekTo(pos);
    }

    /**
     * Verifica si el archivo de audio se está reproduciendo actualmente.
     *
     * @return true si el archivo de audio se está reproduciendo, false en caso contrario.
     */
    @Override
    public boolean isPlaying() {
        return mediaPlayer != null && mediaPlayer.isPlaying();
    }

    /**
     * Obtiene el porcentaje de buffer del archivo de audio.
     *
     * @return El porcentaje de buffer, no se utiliza para reproducción local.
     */
    @Override
    public int getBufferPercentage() {
        return 0; // No es necesario para reproducción local
    }

    /**
     * Indica si la reproducción del archivo de audio puede ser pausada.
     *
     * @return true si la reproducción puede ser pausada, false en caso contrario.
     */
    @Override
    public boolean canPause() {
        return true;
    }

    /**
     * Indica si se puede retroceder en la reproducción del archivo de audio.
     *
     * @return true si se puede retroceder, false en caso contrario.
     */
    @Override
    public boolean canSeekBackward() {
        return true;
    }

    /**
     * Indica si se puede avanzar en la reproducción del archivo de audio.
     *
     * @return true si se puede avanzar, false en caso contrario.
     */
    @Override
    public boolean canSeekForward() {
        return true;
    }

    /**
     * Obtiene el ID de sesión de audio del reproductor multimedia.
     *
     * @return El ID de sesión de audio del reproductor multimedia.
     */
    @Override
    public int getAudioSessionId() {
        return mediaPlayer.getAudioSessionId();
    }

    /**
     * Maneja el evento de toque en la pantalla.
     * Muestra los controles de reproducción si están disponibles.
     *
     * @param event El evento de toque en la pantalla.
     * @return true si el evento ha sido manejado, false en caso contrario.
     */
    @Override
    public boolean onTouchEvent(MotionEvent event) {
        if (mediaController != null) {
            mediaController.show();
        }
        // Devuelve false para permitir que otros elementos manejen el evento de toque
        return false;
    }

    /**
     * Limpia los recursos utilizados por el reproductor multimedia cuando la actividad es destruida.
     */
    @Override
    protected void onDestroy() {
        super.onDestroy();

        // Ocultar el MediaController para prevenir WindowLeaks
        if (mediaController != null) {
            mediaController.removeAllViews();
            mediaController = null; // opcional, depende si quieres reusar MediaController
        }

        // Detener y liberar el MediaPlayer
        if (mediaPlayer != null) {
            if (mediaPlayer.isPlaying()) {
                mediaPlayer.stop();
            }
            mediaPlayer.release();
            mediaPlayer = null;
        }
    }
}