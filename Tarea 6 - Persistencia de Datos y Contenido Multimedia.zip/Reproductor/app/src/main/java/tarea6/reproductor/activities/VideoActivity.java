package tarea6.reproductor.activities;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;

import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.util.Log;
import android.widget.Button;

import java.util.List;

import tarea6.reproductor.databinding.ActivityVideoBinding;
import tarea6.reproductor.resources.MediaAdapter;
import tarea6.reproductor.resources.MediaContentLoader;
import tarea6.reproductor.resources.MediaItem;

/**
 * Actividad que muestra una lista de elementos multimedia de tipo video disponibles para reproducción.
 * Los datos se cargan desde un archivo JSON y se muestran en un RecyclerView utilizando un adaptador personalizado (MediaAdapter).
 * Esta actividad implementa la interfaz OnMediaClickListener para manejar los clics en los elementos multimedia.
 */
public class VideoActivity extends AppCompatActivity implements MediaAdapter.OnMediaClickListener {

    // Declaración de variables
    private ActivityVideoBinding binding; // Binding para acceder a los elementos de la interfaz

    /**
     * Método que se ejecuta al crear la actividad.
     * @param savedInstanceState Instancia guardada de la actividad.
     */
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        binding = ActivityVideoBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());

        // Configurar el recyclerView
        setupRecyclerView();

        // Configurar el botón de regreso
        setupBackButton();
    }

    /**
     * Configura el RecyclerView para mostrar los elementos multimedia disponibles para reproducción.
     * Carga los datos desde un archivo JSON y utiliza un adaptador personalizado (MediaAdapter).
     */
    private void setupRecyclerView() {
        // Cargar los datos desde el archivo JSON
        List<MediaItem> mediaList = MediaContentLoader.loadMediaFromJSON(this, "1");
        MediaAdapter adapter = new MediaAdapter(this, mediaList, this);

        // Configuro el recyclerView
        binding.recyclerViewVideo.setHasFixedSize(true);
        binding.recyclerViewVideo.setAdapter(adapter);
        binding.recyclerViewVideo.setLayoutManager(new LinearLayoutManager(this));
    }

    /**
     * Configura el evento de clic para el botón de regreso.
     * Finaliza la actividad actual cuando se hace clic en el botón de regreso.
     */
    private void setupBackButton() {
        // Encuentra el botón por su ID y configura el evento de clic
        Button buttonBack = binding.buttonBack;
        buttonBack.setOnClickListener(v -> {
            // Finaliza la actividad actual
            finish();
        });
    }

    /**
     * Método llamado cuando se hace clic en un elemento multimedia en el RecyclerView.
     * Abre la actividad del reproductor de video para reproducir el video seleccionado.
     * @param item El elemento multimedia seleccionado.
     */
    @Override
    public void onPlayClicked(MediaItem item) {
        String videoName = item.getUri();
        // Obtiene el identificador del recurso
        int resId = getResources().getIdentifier(videoName, "raw", getPackageName());
        if (resId != 0) { // Asegúrate de que el recurso existe
            // Corrige la construcción de la Uri
            Uri videoUri = Uri.parse("android.resource://" + getPackageName() + "/" + resId);
            Intent intent = new Intent(VideoActivity.this, VideoPlayerActivity.class);
            intent.putExtra("video_uri", videoUri.toString());
            startActivity(intent);
        } else {
            // Manejar el caso donde el recurso no se encontró
            Log.e("VideoActivity", "Recurso no encontrado: " + videoName);
        }
    }
}