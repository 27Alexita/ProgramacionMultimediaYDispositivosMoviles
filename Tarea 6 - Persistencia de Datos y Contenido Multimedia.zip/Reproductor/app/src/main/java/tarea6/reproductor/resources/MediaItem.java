package tarea6.reproductor.resources;

import tarea6.reproductor.R;

/**
 * Esta clase representa un elemento multimedia genérico.
 * Contiene información sobre el nombre, descripción, tipo, URI y la imagen asociada al elemento.
 */
public class MediaItem {

    private String nombre; // Nombre del elemento multimedia
    private String descripcion; // Descripción del elemento multimedia
    private String tipo; // "0" para audio, "1" para video, "2" para streaming
    private String uri; // URI del elemento multimedia
    private String imagen; // Nombre de la imagen asociada al elemento multimedia

    // Constructor
    public MediaItem(String nombre, String descripcion, String tipo, String uri, String imagen) {
        this.nombre = nombre;
        this.descripcion = descripcion;
        this.tipo = tipo;
        this.uri = uri;
        this.imagen = imagen;
    }

    // Getters y setters

    /**
     * Métodos para obtener los atributos de la clase
     */
    // Método que obtiene el nombre del elemento multimedia
    public String getNombre() { return nombre; }
    // Método que obtiene la descripción del elemento multimedia
    public String getDescripcion() { return descripcion; }
    // Método que obtiene el tipo del elemento multimedia
    public String getTipo() { return tipo; }
    // Método que obtiene la URI del elemento multimedia
    public String getUri() { return uri; }
    // Método que obtiene el nombre de la imagen asociada al elemento multimedia
    public String getImagen() { return imagen; }

    /**
     * Métodos para establecer los atributos de la clase
     */
    // Método que establece el nombre del elemento multimedia
    public void setNombre(String nombre) { this.nombre = nombre; }
    // Método que establece la descripción del elemento multimedia
    public void setDescripcion(String descripcion) { this.descripcion = descripcion; }
    // Método que establece el tipo del elemento multimedia
    public void setTipo(String tipo) { this.tipo = tipo; }
    // Método que establece la URI del elemento multimedia
    public void setUri(String uri) { this.uri = uri; }
    // Método que establece el nombre de la imagen asociada al elemento multimedia
    public void setImagen(String imagen) { this.imagen = imagen; }

    /**
     * Métodos para obtener los identificadores de recursos drawable
     */
    // Método que obtiene el identificador de la imagen asociada al elemento multimedia
    public int getTipoImagenDrawable() {
        switch (tipo) {
            case "0": return R.drawable.audiocard;
            case "1": return R.drawable.videocard;
            case "2": return R.drawable.streamingcard;
            default: return R.drawable.ic_launcher_background; // Drawable por defecto
        }
    }

    // Método que obtiene el identificador del botón de play
    public int getPlayButtonDrawable() {
        return R.drawable.play; // Drawable del botón de play
    }
}
