package tarea6.reproductor.activities;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Context;
import android.media.AudioManager;
import android.net.Uri;
import android.os.Bundle;
import android.util.Log;
import android.view.MotionEvent;
import android.widget.Button;
import android.widget.MediaController;
import android.widget.SeekBar;

import tarea6.reproductor.databinding.ActivityVideoPlayerBinding;

/**
 * Actividad que reproduce videos utilizando un VideoView y proporciona controles de reproducción y volumen.
 * Esta actividad puede reproducir videos tanto desde recursos locales como desde URL de streaming.
 * Utiliza View Binding para acceder a los elementos de la interfaz de usuario.
 */
public class VideoPlayerActivity extends AppCompatActivity {

    // Declaración de variables
    private ActivityVideoPlayerBinding binding; // Binding para acceder a los elementos de la interfaz
    private MediaController mediaController; // Controlador de medios para el VideoView
    private AudioManager audioManager; // Administrador de audio para controlar el volumen
    private int currentPosition = 0; // Posición actual del video

    /**
     * Método que se ejecuta al crear la actividad.
     * @param savedInstanceState Instancia guardada de la actividad.
     */
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        // Inflar la vista con View Binding
        binding = ActivityVideoPlayerBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());

        // Configuro el MediaController
        setupMediaController();

        // Configurar el VideoView y reproducir el video desde la URI proporcionada en el Intent o la URL de streaming
        playVideoFromIntentOrStreaming();

        // Configuro la barra de volumen
        setupVolumeControl();

        // Configurar el botón de regreso
        setupBackButton();
    }

    /**
     * Configura el MediaController para controlar la reproducción del video.
     */
    private void setupMediaController() {
        mediaController = new MediaController(this);
        mediaController.setAnchorView(binding.videoView);
        binding.videoView.setMediaController(mediaController);
    }

    /**
     * Reproduce el video desde la URI proporcionada en el Intent o la URL de streaming.
     */
    private void playVideoFromIntentOrStreaming() {
        String videoUriString = getIntent().getStringExtra("video_uri");
        if (videoUriString != null) {
            Uri videoUri;
            // Verifica si la URI del vídeo es una URL de streaming o un nombre de recurso local
            if (videoUriString.startsWith("http://") || videoUriString.startsWith("https://")) {
                // Si es una URL de streaming, parsea la URI directamente
                videoUri = Uri.parse(videoUriString);
            } else {
                // Si es un nombre de recurso local, obtiene el ID del recurso
                int resId = getResources().getIdentifier(videoUriString, "raw", getPackageName());
                if (resId == 0) {
                    // El recurso no se encontró, podrías manejar este caso con un mensaje de error o una acción específica
                    Log.e("VideoPlayerActivity", "El recurso de vídeo no se encontró: " + videoUriString);
                    return;
                }
                videoUri = Uri.parse("android.resource://" + getPackageName() + "/" + resId);
            }
            // Configurar la URI del video en el VideoView
            binding.videoView.setVideoURI(videoUri);
            binding.videoView.setOnPreparedListener(mp -> {
                // Muestra el MediaController indefinidamente cuando el vídeo está listo
                mediaController.show(Integer.MAX_VALUE);
                // Inicia la reproducción del vídeo automáticamente
                binding.videoView.start();
            });
        } else {
            // No hay URI de vídeo, podrías manejar este caso con un mensaje de error o una acción específica
            Log.e("VideoPlayerActivity", "No se proporcionó ninguna URI de vídeo.");
        }
    }

    /**
     * Configura los controles de volumen utilizando el AudioManager y una SeekBar.
     */
    private void setupVolumeControl() {
        audioManager = (AudioManager) getSystemService(Context.AUDIO_SERVICE);
        binding.seekBarVolume.setMax(audioManager.getStreamMaxVolume(AudioManager.STREAM_MUSIC));
        binding.seekBarVolume.setProgress(audioManager.getStreamVolume(AudioManager.STREAM_MUSIC));

        binding.seekBarVolume.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            @Override
            public void onProgressChanged(SeekBar seekBar, int progress, boolean fromUser) {
                audioManager.setStreamVolume(AudioManager.STREAM_MUSIC, progress, AudioManager.FLAG_SHOW_UI);
            }

            @Override
            public void onStartTrackingTouch(SeekBar seekBar) {

            }

            @Override
            public void onStopTrackingTouch(SeekBar seekBar) {

            }
        });
    }

    /**
     * Configura el evento de clic para el botón de regreso.
     * Finaliza la actividad actual cuando se hace clic en el botón de regreso.
     */
    private void setupBackButton() {
        // Encuentra el botón por su ID y configura el evento de clic
        Button buttonBack = binding.buttonBack;
        buttonBack.setOnClickListener(v -> {
            // Finaliza la actividad actual
            finish();
        });
    }

    /**
     * Método llamado cuando la actividad se pausa.
     * Pausa la reproducción del video y oculta el MediaController cuando la actividad está pausada.
     */
    @Override
    protected void onPause() {
        super.onPause();
        // Pausar el video cuando la actividad esté pausada
        if (binding.videoView.isPlaying()) {
            binding.videoView.pause();
            // Guardar la posición actual para reanudarla más tarde
            currentPosition = binding.videoView.getCurrentPosition();
        }
        // Ocultar el MediaController si está visible
        if (mediaController != null && mediaController.isShowing()) {
            mediaController.hide();
        }
    }

    /**
     * Método llamado cuando la actividad se reanuda.
     * Reanuda la reproducción del video y muestra el MediaController si estaba visible.
     */
    @Override
    protected void onResume() {
        super.onResume();
        // Reanudar el video cuando la actividad se reanude
        if (currentPosition > 0) {
            binding.videoView.seekTo(currentPosition);
            binding.videoView.start();
        }
        // Mostrar el MediaController si el video está reproduciéndose
        if (binding.videoView.isPlaying()) {
            mediaController.show();
        }
    }

    /**
     * Método llamado cuando se detecta un evento táctil en la actividad.
     * Muestra el MediaController cuando se detecta un evento táctil en la actividad.
     * @param event El evento táctil detectado.
     * @return True para indicar que el evento ha sido manejado.
     */
    @Override
    public boolean onTouchEvent(MotionEvent event) {
        if (mediaController != null) {
            mediaController.show();
        }
        // Devuelve true para indicar que el evento ha sido manejado
        return true;
    }

    /**
     * Método llamado cuando la actividad está siendo destruida.
     * Detiene la reproducción del video y libera los recursos asociados.
     * También asegura que el MediaController no cause fugas de ventana.
     */
    @Override
    protected void onDestroy() {
        super.onDestroy();

        // Detiene la reproducción del video para liberar recursos
        if (binding.videoView != null) {
            binding.videoView.stopPlayback();
        }

        // Asegura que el MediaController no cause fugas de ventana
        if (mediaController != null) {
            mediaController.removeAllViews();
            mediaController = null;
        }
        // Nota: No es necesario liberar el MediaPlayer explícitamente al usar VideoView,
        // ya que VideoView maneja el ciclo de vida del MediaPlayer internamente.
    }
}